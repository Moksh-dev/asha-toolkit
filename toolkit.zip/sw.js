const CACHE='asha-toolkit-cc344d83ee6f';
const ASSETS=["/assets/index-DPw3U7E9.css","/assets/index-DojZmudm.js","/icon.svg","/index.html","/manifest.webmanifest","/offline-toolkit.html"];
self.addEventListener('install', event => event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(ASSETS)).then(() => self.skipWaiting())));
self.addEventListener('activate', event => event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith('asha-toolkit-') && key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim())));
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET' || new URL(event.request.url).origin !== self.location.origin) return;
  if (event.request.mode === 'navigate') {
    event.respondWith(caches.open(CACHE).then(async cache => (await cache.match(event.request, {ignoreSearch:true,ignoreVary:true})) || (await cache.match('/index.html')) || fetch(event.request)));
  } else {
    event.respondWith(caches.open(CACHE).then(cache => cache.match(event.request, {ignoreSearch:true,ignoreVary:true})).then(hit => hit || fetch(event.request)));
  }
});